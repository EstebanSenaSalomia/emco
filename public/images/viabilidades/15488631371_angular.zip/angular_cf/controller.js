var app = angular.module("app",[]);
app.controller("controller",function($scope){
    $scope.nombre="esteban Cardona";
    $scope.nuevoComentario={};//aqui declaramos 
    $scope.comentarios = [
        {
            comentario: "Gracias por el video",
            username: "soy el mejor"
        },
        {
            comentario: "codigo facilito",
            username: "esteban cardona"
        }
    ];
    $scope.agregarComentario = function(){ //creamos una funcion con el nombre agregar comentario
        $scope.comentarios.push($scope.nuevoComentario); //con push agregamos un nueov nodo al arreglo 'comentarios'
        //nuevoComentario es recibido como parametro para ingresarlo a 'cometario' quien es el arreglo,
        //nuevoComentario sera mandado desde la vista
        $scope.nuevoComentario = {};//volvemos a declara para reiniciar los campos y queden vacios

        
    }
});
