

var app = angular
.module("app",[])
.controller("controller",function($scope,$http){
	$scope.posts = [];
	$http({
	  method: 'GET',
	  url: 'http://jsonplaceholder.typicode.com/posts'
	}).then(function(response) {
	    console.log(response.data);
	    $scope.posts = response.data;
	  }, function(err) {
	    console.log(err);
	  });
});